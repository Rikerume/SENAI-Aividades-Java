package Aplicacao;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import Elementos.funcGeral;
import Elementos.funcProprio;
import Elementos.funcTerceirizado;

public class Main {

	public static void main(String[] args) {
		List<funcGeral> func_Prop = new ArrayList<funcGeral>();
		Scanner sc = new Scanner(System.in);
		int op = 0;
		
		
		System.out.println("Informe a quantidade de ususarios: ");
		int n = sc.nextInt();

		for (int x = 0; x < n; x++) {
			
			System.out.println("\nInforme o tipo de funcionario:\n[1]Funcionario Proprio\n[2]Funcionario Terceirizado");
			op = sc.nextInt();
			if(op==1) {
				funcProprio.AddFuncionarioProp(sc, func_Prop);
			}
			if(op==2) {
				funcTerceirizado.AddFuncionarioTerceiro(sc, func_Prop);
			}
		}
		System.out.println("\nCadastro(s) realizado(s)\nAperte [Enter] para ver os funcionarios cadastrados");
		
		funcGeral.ExibirFuncionario(func_Prop);
		
		

		sc.close();
	}

}
