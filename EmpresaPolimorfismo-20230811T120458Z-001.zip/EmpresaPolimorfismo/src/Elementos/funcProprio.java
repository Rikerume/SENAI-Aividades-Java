package Elementos;

import java.util.List;
import java.util.Scanner;

public class funcProprio extends funcGeral{
	
	public funcProprio(String nome, int horasTrab, double valorHora) {
		super(nome, horasTrab, valorHora);
	}
	
	
	
	public static void AddFuncionarioProp(Scanner sc, List<funcGeral> funcionarios) {
	
		System.out.println("--FUNCIONARIO - PROPRIO--");	
		System.out.println("Informe o nome do funcionario: ");
		String nome = sc.next();
		System.out.println("Informe as horas trabalhadas do funcionario: ");
		int HorasTrab = sc.nextInt();
		System.out.println("Informe o valor que o funcionario ganha por hora: ");
		double ValorHora = sc.nextDouble();
		funcProprio Func_Prop = new funcProprio(nome, HorasTrab, ValorHora);
		funcionarios.add(Func_Prop);
	}
	

	
	
	public double salarioProp(int horasTrab, double valorHora) {
		return horasTrab * valorHora;
	}

	
	
	public String toString() {
		return "\n---------------------------------" +
				"\nNome: " + getNome() + 
				"\nFuncionario - Proprio" + 
				"\nSalario: R$" + salarioProp(getHorasTrab(), getValorHora());
	}

}
