package Elementos;

import java.util.List;
import java.util.Scanner;

public class funcTerceirizado extends funcGeral {
	private double despesaAdd;
	
	public static void AddFuncionarioTerceiro(Scanner sc, List<funcGeral> funcionarios) {
		
		System.out.println("--FUNCIONARIO - TERCEIRIZADO--");
		System.out.println("Informe o nome do funcionario: ");
		String nome = sc.next();
		System.out.println("Informe as horas trabalhadas do funcionario: ");
		int HorasTrab = sc.nextInt();
		System.out.println("Informe o valor que o funcionario ganha por hora: ");
		double ValorHora = sc.nextDouble();
		System.out.println("Informe o valor da despesa: ");
		double despesaAdd = sc.nextDouble();
		funcTerceirizado Func_Prop = new funcTerceirizado(nome, HorasTrab, ValorHora, despesaAdd);
		funcionarios.add(Func_Prop);
		
		}

	
	public funcTerceirizado(String nome, int horasTrab, double valorHora, double Despesa) {
		super(nome, horasTrab, valorHora);
		this.despesaAdd=Despesa;
	}
	
	public double salarioTerceirizado(int horasTrab, double valorHora, double Despesa) {
		return (horasTrab * valorHora)+(despesaAdd+despesaAdd*0.1);
	}	
	
	
	public String toString() {
		return "\n---------------------------------" +
				"\nNome: " + getNome() + 
				"\nFuncionario - Terceirizado" + 
				"\nSalario: R$" + salarioTerceirizado(getHorasTrab(), getValorHora(), despesaAdd);
	}

}
