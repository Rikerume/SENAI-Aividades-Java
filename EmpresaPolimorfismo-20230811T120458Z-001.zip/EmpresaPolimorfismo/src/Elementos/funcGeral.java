package Elementos;

import java.util.List;

public class funcGeral {
	private String nome;
	private int horasTrab;
	private double valorHora;
	
	
	public funcGeral(String nome, int horasTrab, double valorHora) {
		this.nome = nome;
		this.horasTrab = horasTrab;
		this.valorHora = valorHora;
	}
	
	
	
	public static void ExibirFuncionario(List<funcGeral> funcionarios) {
		for (funcGeral func_Prop : funcionarios) {
			System.out.println(func_Prop);
		}
	}
	
	
	
/////////////////////////////////////////////////////	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getHorasTrab() {
		return horasTrab;
	}
	public void setHorasTrab(int horasTrab) {
		this.horasTrab = horasTrab;
	}
	public double getValorHora() {
		return valorHora;
	}
	public void setValorHora(double valorHora) {
		this.valorHora = valorHora;		
	}
/////////////////////////////////////////////////////	

}
